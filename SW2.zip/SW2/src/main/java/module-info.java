module c195.sw2 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires mysql.connector.j;


    opens SqlDB;
    exports c195.sw2;
    opens c195.sw2;
    //exports SqlDB;
}