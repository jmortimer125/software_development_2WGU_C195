"Sw2" Software 2 Scheduling software for WGU C195
A program designed to handle appointment scheduling of customers from multiple locations and timezones
efficiently without error or over scheduling.

Author
Jonathan Mortimer
email- jmorti5@wgu.edu
phone-314-359-8961
student application version 1.0 7/31/23

javaFX jdk-19
corretto 17.0.5
mysql connector j 8.0.33
IntelliJ IDEA 2022.2.5

To Run Program:
select Main.java and click the green run arrow in the top right of intelliJ
when the log in screen is launched enter username/password "test/test" or "admin/admin"
once logged on the intuitive buttons will lead you through the process of adding,editing,and deleting customers and
appointments.

all appointments are saved in 24Hr UTC but displayed in local 12Hr format.

The third report on the reports page "Appointments by User" displays the total amount of appointments each valid user has.
